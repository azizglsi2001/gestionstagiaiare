export interface Utilisateur {
  id: number; 
  nom: string;
  prenom: string;
  role: string;
  etat: string;
  password:string;
  email: string;
}