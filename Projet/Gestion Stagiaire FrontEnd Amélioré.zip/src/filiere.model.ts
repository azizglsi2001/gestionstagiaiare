export interface Filiere {
  id: number;
  nom: string;
}
