export interface Stagiaire {
  id: number; 
  nom: string;
  prenom: string;
  age: number;
  filiere: string;
  taches:string;
}
